package com.api_gestion_horas_extras;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGestionHorasExtrasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGestionHorasExtrasApplication.class, args);
	}

}
