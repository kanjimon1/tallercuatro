package com.api_gestion_horas_extras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGestionHorasExtrasApplicationTests {

	@Test
	void contextLoads() {
	}

}
